%% Inner loop parameters for the crazyflie
% Loop rate at 500 Hz
inner_h = 0.002; 

% Omega saturation
inner_maxlim = 2500;
inner_minlim = 0;%500;