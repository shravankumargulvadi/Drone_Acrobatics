%% Crazyflie controller parameters
% Parameters for PD-control
KzP = 10; KetaP = 16*[1 1 1];
KzD = 5; KetaD = 9*[1 1 1];