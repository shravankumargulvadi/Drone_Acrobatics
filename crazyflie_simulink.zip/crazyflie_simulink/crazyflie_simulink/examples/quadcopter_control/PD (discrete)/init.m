run('init_inner_PD_d')
max_ang_ref = pi/8;