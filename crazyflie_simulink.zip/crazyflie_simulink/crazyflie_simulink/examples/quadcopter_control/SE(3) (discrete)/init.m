% trajectory = load('trajTypeAZeroStart.mat');
trajectory = load('trajTypeB.mat');
%trajectory = load('trajTypeDzero.mat');
trajectory.h = inner_h;