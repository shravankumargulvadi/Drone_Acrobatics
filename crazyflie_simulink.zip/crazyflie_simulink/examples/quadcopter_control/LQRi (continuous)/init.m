run('init_inner_LQRi')
max_ang_ref = 0.5;