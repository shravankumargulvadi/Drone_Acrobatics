% RUN EACH SESSION SUBSEQUENTLY
run('init_inner_PD_d')
max_ang_ref = pi/8;

% Chose number of flips to execute
FLIP = 2;
% Climbing phase determined by start_time and ref

% Flip Controller
params.h = 0.002;  % time step
params.lambda = 50;
params.af = [1; 0; 0];
params.K_omega = 2.0/1000;
params.K_alpha = 5/1000000;

% LQR Controller
K12 = [0,0,0.500000000000000,0,0,0.166375000000000,0,0,0,0,0,0;0,-0.000711512473537874,0,0,-0.00298424248869664,0,0.0242813448457065,0,0,0.00316284410733867,0,0;0.000711512473537946,0,0,0.00298424248869694,0,0,0,0.0242813448457095,0,0,0.00316284410733867,0;0,0,0,0,0,0,0,0,0.00666666666666733,0,0,0.00316320407182333];
K8 = [0.0790569415042096,0.0700000000000000,0,0,0,0,0,0;0,0,0.000790569415042095,0,0,0.000262795978174799,0,0;0,0,0,0.000790569415042096,0,0,0.000262795978174799,0;0,0,0,0,0.000790569415042096,0,0,0.000272179797065041];

if (FLIP==1)
    % Single flip config => 6.28
    disp("SINGLE FLIP, PLEASE CALCULATE");
    params.Phi_g1 = 180;
    params.Phi_g2 = 0;
    params.Phi_g3 = 180;
    params.omega_max = 1400;
    params.start_time = 0.15;
    params.duration = 0.5;
end
if (FLIP==2)
    % Double flip config => 12.56
    disp("DOUBLE FLIP, PLEASE CALCULATE");
    params.Phi_g1 = 200;
    params.Phi_g2 = 300;
    params.Phi_g3 = 220;
    params.omega_max = 1600;
    params.start_time = 0.25;
    params.duration = 0.7;
end
if (FLIP==3)
% Triple flip config => 18.84
    disp("TRIPLE FLIP, PLEASE CALCULATE");
    params.Phi_g1 = 220;
    params.Phi_g2 = 520;
    params.Phi_g3 = 340;
    params.omega_max = 2000;
    params.start_time = 0.3;
    params.duration = 0.8;
end
% Calculation
% Stage 1
params.gamma1 = params.omega_max\params.Phi_g1;
params.beta1 = -(3/4)*params.omega_max/params.gamma1^3;
params.omega_dot_max1 = (3/4)*params.omega_max^2/params.Phi_g1;
params.delta1 = 2*params.gamma1;
% Stage 2
params.delta2 = params.Phi_g2/params.omega_max;
% Stage 3
params.gamma3 = params.omega_max\params.Phi_g3;
params.beta3 = -(3/4)*params.omega_max/params.gamma3^3;
params.omega_dot_max3 = (3/4)*params.omega_max^2/params.Phi_g3;
params.delta3 = 2*params.gamma3;
disp("CALCULATED, RUN SIMULATION");