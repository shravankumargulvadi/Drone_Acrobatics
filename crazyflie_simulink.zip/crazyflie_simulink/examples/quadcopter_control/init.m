run('init_quadcopter_model');
run('init_inner_controller');
fprintf(['Proceed by running the init file in any sub directory,\n',...
         'followed by running the corresponding model.\n'])